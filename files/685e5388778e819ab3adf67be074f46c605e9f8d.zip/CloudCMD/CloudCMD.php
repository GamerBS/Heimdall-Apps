<?php namespace App\SupportedApps\CloudCMD;

class CloudCMD extends \App\SupportedApps
{
}
