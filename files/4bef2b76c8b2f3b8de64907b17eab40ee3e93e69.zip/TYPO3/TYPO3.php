<?php namespace App\SupportedApps\TYPO3;

class TYPO3 extends \App\SupportedApps
{
}
