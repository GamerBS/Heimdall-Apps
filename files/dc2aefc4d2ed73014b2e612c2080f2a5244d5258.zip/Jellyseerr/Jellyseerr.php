<?php namespace App\SupportedApps\Jellyseerr;

class Jellyseerr extends \App\SupportedApps {

}
