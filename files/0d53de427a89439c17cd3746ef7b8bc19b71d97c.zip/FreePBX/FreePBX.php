<?php namespace App\SupportedApps\FreePBX;

class FreePBX extends \App\SupportedApps
{
}
