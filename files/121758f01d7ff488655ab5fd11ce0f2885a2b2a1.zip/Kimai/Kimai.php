<?php namespace App\SupportedApps\Kimai;

class Kimai extends \App\SupportedApps
{
}
