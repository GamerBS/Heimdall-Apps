<ul class="livestats">
    <li><span class="title">Queue</span><strong>{!! $queue_size !!}</strong></li>
    <li><span class="title">Speed</span><strong>{!! $current_speed !!}/s</span></strong></li>
</ul>
