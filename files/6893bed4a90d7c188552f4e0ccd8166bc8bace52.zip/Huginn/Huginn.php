<?php namespace App\SupportedApps\Huginn;

class Huginn extends \App\SupportedApps
{
}
