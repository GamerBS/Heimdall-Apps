<?php namespace App\SupportedApps\iDRAC;

class iDRAC extends \App\SupportedApps
{
}
