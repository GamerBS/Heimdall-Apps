<?php namespace App\SupportedApps\Asuswrt;

class Asuswrt extends \App\SupportedApps {

}