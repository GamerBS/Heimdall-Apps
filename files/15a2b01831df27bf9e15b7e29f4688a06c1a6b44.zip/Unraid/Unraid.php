<?php namespace App\SupportedApps\Unraid;

class Unraid extends \App\SupportedApps
{
}
