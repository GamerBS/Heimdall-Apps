<?php namespace App\SupportedApps\Requestrr;

class Requestrr extends \App\SupportedApps
{
}
